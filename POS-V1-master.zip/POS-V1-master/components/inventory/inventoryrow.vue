<template>
    <tr >
        <th scope="row" >
            {{ itemobejct.name }}
        </th>
        <td >
            {{ itemobejct.color }}
        </td>
        <td >
            {{ itemobejct.category }}
        </td>
        <td >
            ${{ itemobejct.price }}
        </td>
        <td >
            {{ itemobejct.deleted }}
        </td>
        <td >
            <ItemEditItem :itemId="itemobejct.id" />
        </td>
    </tr>
</template>

<script setup>

const props = defineProps({
    itemobejct: {
        type: Object,
        required: false
    },

});
const { addItem } = useCart();

const handleEditItem = () => {
    props.itemobejct.quantity = 1;
    addItem(props.itemobejct);
    toast.add({ title: 'Added to cart!' })
};
</script>
