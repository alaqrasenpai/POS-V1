<template>
    <div >
        <NuxtLink to="/">
            <n-layout>
                <n-layout-content content-style="padding: 24px;">
                    Home
                </n-layout-content>
            </n-layout>
        </NuxtLink>
        <NuxtLink to="/sellorder">
            <n-layout>
                <n-layout-content content-style="padding: 24px;">
                    Sell Order
                </n-layout-content>
            </n-layout>
        </NuxtLink>
        <NuxtLink to="/inventory">
            <n-layout>
                <n-layout-content content-style="padding: 24px;">
                    Inventory
                </n-layout-content>
            </n-layout>
        </NuxtLink>

        <NuxtLink to="/tabs">
            <n-layout>
                <n-layout-content content-style="padding: 24px;">
                    Tabs
                </n-layout-content>
            </n-layout>
        </NuxtLink>
        <NuxtLink to="/category">
            <n-layout>
                <n-layout-content content-style="padding: 24px;">
                    Categories
                </n-layout-content>
            </n-layout>
        </NuxtLink>





        <div
            >
            <i ></i>
            <span >Logout</span>
        </div>
    </div>

</template>
<script setup>
</script>